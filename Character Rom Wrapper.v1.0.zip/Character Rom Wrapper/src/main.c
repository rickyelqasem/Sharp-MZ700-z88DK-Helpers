#include <conio.h>
#include <stdint.h>

#define SCREEN_WIDTH 40
#define SCREEN_HEIGHT 25

#define DISPLAY_BASE ((volatile uint8_t *)0xD000)
#define COLOUR_BASE ((volatile uint8_t *)0xD800)

#define COLOUR_SET_A 0x70
#define COLOUR_SET_B 0xF0

#define CHARSET_ASCII 0
#define CHARSET_DISPLAY_A 1
#define CHARSET_DISPLAY_B 2

static uint8_t mz_encode_ui_char(uint8_t ch);
static uint8_t mz_encode_ascii_preview(uint8_t ch);
static uint8_t mz_make_preview_colour(uint8_t mode, uint8_t fg, uint8_t bg);
static const char *mz_colour_name(uint8_t colour);
static void mz_put_code(uint8_t x, uint8_t y, uint8_t code, uint8_t colour);
static void mz_put_text(uint8_t x, uint8_t y, const char *text, uint8_t colour);
static void mz_clear_screen(uint8_t colour);
static void mz_tiny_delay(void);
static void mz_wait_for_key_release(void);
static uint8_t mz_choose_charset(void);
static void mz_write_hex8(uint8_t x, uint8_t y, uint8_t value, uint8_t colour);
static void mz_write_dec3(uint8_t x, uint8_t y, uint8_t value, uint8_t colour);
static uint8_t mz_is_control_code(uint8_t mode, uint8_t value);
static void mz_clear_row_segment(uint8_t x, uint8_t y, uint8_t width, uint8_t colour);
static void mz_draw_preview(uint8_t mode, uint8_t value, uint8_t fg, uint8_t bg);
static void mz_draw_static_ui(void);
static void mz_update_ui(uint8_t mode, uint8_t value, uint8_t fg, uint8_t bg);

static const char *const MODE_NAMES[] = {
    "ASCII",
    "DISPLAY A",
    "DISPLAY B"
};

static const char *const COLOUR_NAMES[] = {
    "BLACK",
    "BLUE",
    "RED",
    "PURPLE",
    "GREEN",
    "LT BLUE",
    "YELLOW",
    "WHITE"
};

static uint8_t mz_encode_ui_char(uint8_t ch)
{
    if (ch == ' ') {
        return 0x00;
    }

    if (ch >= '0' && ch <= '9') {
        return (uint8_t)(ch - 16);
    }

    if (ch >= 'A' && ch <= 'Z') {
        return (uint8_t)(ch - 64);
    }

    if (ch >= 'a' && ch <= 'z') {
        return (uint8_t)(ch + 32);
    }

    switch (ch) {
    case '-':
        return 0x60;
    default:
        return 0x00;
    }
}

static uint8_t mz_encode_ascii_preview(uint8_t ch)
{
    if (ch == ' ') {
        return 0x00;
    }

    if (ch >= '0' && ch <= '9') {
        return (uint8_t)(ch - 16);
    }

    if (ch >= 'A' && ch <= 'Z') {
        return (uint8_t)(ch - 64);
    }

    if (ch >= 'a' && ch <= 'z') {
        return (uint8_t)(ch + 32);
    }

    switch (ch) {
    case '!':
        return 0x61;
    case '"':
        return 0x62;
    case '#':
        return 0x63;
    case '$':
        return 0x64;
    case '%':
        return 0x65;
    case '&':
        return 0x66;
    case '\'':
        return 0x67;
    case '(':
        return 0x68;
    case ')':
        return 0x69;
    case '*':
        return 0x6A;
    case '+':
        return 0x6B;
    case ',':
        return 0x6C;
    case '-':
        return 0x6D;
    case '.':
        return 0x6E;
    case '/':
        return 0x6F;
    case ':':
        return 0x70;
    case ';':
        return 0x71;
    case '<':
        return 0x72;
    case '=':
        return 0x73;
    case '>':
        return 0x74;
    case '?':
        return 0x75;
    default:
        return 0x00;
    }
}

static uint8_t mz_make_preview_colour(uint8_t mode, uint8_t fg, uint8_t bg)
{
    uint8_t colour = (uint8_t)(((fg & 0x07) << 4) | (bg & 0x07));

    if (mode == CHARSET_DISPLAY_B) {
        colour |= 0x80;
    }

    return colour;
}

static const char *mz_colour_name(uint8_t colour)
{
    return COLOUR_NAMES[colour & 0x07];
}

static void mz_put_code(uint8_t x, uint8_t y, uint8_t code, uint8_t colour)
{
    uint16_t offset;

    if (x >= SCREEN_WIDTH || y >= SCREEN_HEIGHT) {
        return;
    }

    offset = ((uint16_t)y * SCREEN_WIDTH) + x;
    DISPLAY_BASE[offset] = code;
    COLOUR_BASE[offset] = colour;
}

static void mz_put_text(uint8_t x, uint8_t y, const char *text, uint8_t colour)
{
    uint8_t px = x;
    uint8_t py = y;

    while (*text != 0) {
        if (*text == '\n') {
            ++py;
            px = x;
        } else {
            mz_put_code(px, py, mz_encode_ui_char((uint8_t)*text), colour);
            ++px;
        }
        ++text;
    }
}

static void mz_clear_screen(uint8_t colour)
{
    uint16_t i;

    for (i = 0; i < (SCREEN_WIDTH * SCREEN_HEIGHT); ++i) {
        DISPLAY_BASE[i] = mz_encode_ui_char(' ');
        COLOUR_BASE[i] = colour;
    }
}

static void mz_tiny_delay(void)
{
    uint16_t i;

    for (i = 0; i < 3000; ++i) {
    }
}

static void mz_wait_for_key_release(void)
{
    while (getk() != 0) {
        mz_tiny_delay();
    }
}

static uint8_t mz_choose_charset(void)
{
    uint8_t key;

    mz_clear_screen(COLOUR_SET_A);
    mz_put_text(4, 4, "MZ700 CHARACTER BROWSER", COLOUR_SET_A);
    mz_put_text(4, 7, "PRESS 1 FOR ASCII", COLOUR_SET_A);
    mz_put_text(4, 9, "PRESS 2 FOR DISPLAY A", COLOUR_SET_A);
    mz_put_text(4, 11, "PRESS 3 FOR DISPLAY B", COLOUR_SET_A);

    for (;;) {
        key = getk();
        if (key == '1') {
            mz_wait_for_key_release();
            return CHARSET_ASCII;
        }
        if (key == '2') {
            mz_wait_for_key_release();
            return CHARSET_DISPLAY_A;
        }
        if (key == '3') {
            mz_wait_for_key_release();
            return CHARSET_DISPLAY_B;
        }
    }
}

static void mz_write_hex8(uint8_t x, uint8_t y, uint8_t value, uint8_t colour)
{
    static const char HEX[] = "0123456789ABCDEF";

    mz_put_code(x, y, mz_encode_ui_char(HEX[(value >> 4) & 0x0F]), colour);
    mz_put_code(x + 1, y, mz_encode_ui_char(HEX[value & 0x0F]), colour);
}

static void mz_write_dec3(uint8_t x, uint8_t y, uint8_t value, uint8_t colour)
{
    uint8_t hundreds = value / 100;
    uint8_t tens = (value / 10) % 10;
    uint8_t ones = value % 10;

    mz_put_code(x, y, mz_encode_ui_char((uint8_t)('0' + hundreds)), colour);
    mz_put_code(x + 1, y, mz_encode_ui_char((uint8_t)('0' + tens)), colour);
    mz_put_code(x + 2, y, mz_encode_ui_char((uint8_t)('0' + ones)), colour);
}

static uint8_t mz_is_control_code(uint8_t mode, uint8_t value)
{
    if (mode == CHARSET_ASCII) {
        if (value == 0x0D) {
            return 1;
        }
        if (value >= 0x11 && value <= 0x16) {
            return 1;
        }
    }

    if (mode == CHARSET_DISPLAY_A) {
        if (value >= 0xC1 && value <= 0xC6) {
            return 1;
        }
    }

    return 0;
}

static void mz_clear_row_segment(uint8_t x, uint8_t y, uint8_t width, uint8_t colour)
{
    uint8_t i;

    for (i = 0; i < width; ++i) {
        mz_put_code(x + i, y, mz_encode_ui_char(' '), colour);
    }
}

static void mz_draw_preview(uint8_t mode, uint8_t value, uint8_t fg, uint8_t bg)
{
    uint8_t preview_code;
    uint8_t preview_colour;

    preview_colour = mz_make_preview_colour(mode, fg, bg);

    if (mz_is_control_code(mode, value)) {
        preview_code = mz_encode_ui_char(' ');
    } else if (mode == CHARSET_ASCII) {
        preview_code = mz_encode_ascii_preview(value);
    } else {
        preview_code = value;
    }

    mz_put_code(20, 11, preview_code, preview_colour);
}

static void mz_draw_static_ui(void)
{
    mz_clear_screen(COLOUR_SET_A);

    mz_put_text(2, 1, "MZ700 CHARACTER BROWSER", COLOUR_SET_A);
    mz_put_text(2, 3, "SET", COLOUR_SET_A);
    mz_put_text(2, 5, "HEX", COLOUR_SET_A);
    mz_put_text(14, 5, "DEC", COLOUR_SET_A);
    mz_put_text(2, 18, "FG", COLOUR_SET_A);
    mz_put_text(2, 19, "BG", COLOUR_SET_A);
    mz_put_text(2, 21, "A NEXT  Z PREVIOUS", COLOUR_SET_A);
    mz_put_text(2, 22, "N FG COLOUR  M BG COLOUR", COLOUR_SET_A);
    mz_put_text(2, 23, "1 ASCII  2 DISP A  3 DISP B", COLOUR_SET_A);
    mz_put_text(2, 24, "Q QUIT", COLOUR_SET_A);
}

static void mz_update_ui(uint8_t mode, uint8_t value, uint8_t fg, uint8_t bg)
{
    mz_clear_row_segment(7, 3, 12, COLOUR_SET_A);
    mz_put_text(7, 3, MODE_NAMES[mode], COLOUR_SET_A);
    mz_write_hex8(7, 5, value, COLOUR_SET_A);
    mz_write_dec3(19, 5, value, COLOUR_SET_A);

    mz_clear_row_segment(2, 7, 36, COLOUR_SET_A);
    if (mode == CHARSET_ASCII) {
        mz_put_text(2, 7, "ASCII USES ROM TRANSLATION", COLOUR_SET_A);
    } else if (mode == CHARSET_DISPLAY_A) {
        mz_put_text(2, 7, "DISPLAY A USES NORMAL COLOUR RAM", COLOUR_SET_A);
    } else {
        mz_put_text(2, 7, "DISPLAY B SETS COLOUR HIGH BIT", COLOUR_SET_A);
    }

    mz_clear_row_segment(5, 18, 12, COLOUR_SET_A);
    mz_put_text(5, 18, mz_colour_name(fg), COLOUR_SET_A);
    mz_clear_row_segment(5, 19, 12, COLOUR_SET_A);
    mz_put_text(5, 19, mz_colour_name(bg), COLOUR_SET_A);

    mz_draw_preview(mode, value, fg, bg);

    mz_clear_row_segment(2, 16, 30, COLOUR_SET_A);
    if (mz_is_control_code(mode, value)) {
        mz_put_text(2, 16, "CONTROL CODE NO PREVIEW", COLOUR_SET_A);
    } else {
        mz_put_text(2, 16, "ONE CHARACTER PREVIEW", COLOUR_SET_A);
    }
}

int main(void)
{
    uint8_t mode;
    uint8_t value = 0;
    uint8_t fg = 7;
    uint8_t bg = 0;
    uint8_t key;

    mode = mz_choose_charset();
    mz_draw_static_ui();
    mz_update_ui(mode, value, fg, bg);

    for (;;) {
        for (;;) {
            key = getk();
            if (key != 0) {
                break;
            }
        }

        if (key == 'a' || key == 'A') {
            ++value;
        } else if (key == 'z' || key == 'Z') {
            --value;
        } else if (key == 'n' || key == 'N') {
            fg = (uint8_t)((fg + 1) & 0x07);
        } else if (key == 'm' || key == 'M') {
            bg = (uint8_t)((bg + 1) & 0x07);
        } else if (key == '1') {
            mode = CHARSET_ASCII;
            value = 0;
        } else if (key == '2') {
            mode = CHARSET_DISPLAY_A;
            value = 0;
        } else if (key == '3') {
            mode = CHARSET_DISPLAY_B;
            value = 0;
        } else if (key == 'q' || key == 'Q') {
            break;
        }

        mz_update_ui(mode, value, fg, bg);
        mz_wait_for_key_release();
    }

    mz_clear_screen(COLOUR_SET_A);
    mz_put_text(10, 12, "END OF TEST", COLOUR_SET_A);

    return 0;
}
