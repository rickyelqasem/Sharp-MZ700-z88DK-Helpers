# Character Rom Wrapper

Small Sharp MZ-700 test app for z88dk.

## Build

Run:

```powershell
.\build.ps1
```

This uses the local z88dk install at:

`C:\Users\ricky\Downloads\z88dk-win32-2.4\z88dk`

## Controls

- `1`: ASCII set
- `2`: display set A
- `3`: display set B
- `A`: next code
- `B`: previous code
- `Q`: quit

## Notes

- ASCII mode translates the current MZ-700 ASCII code through monitor routine `$0BB9`.
- Display B preview sets the high bit in colour RAM to select the second display character set.
